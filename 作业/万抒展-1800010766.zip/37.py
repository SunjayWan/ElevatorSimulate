def pykeys(slist):
    import keyword
    keydic = {i:0 for i in keyword.kwlist}
    def count_keys(s):
        nonlocal keydic
        textfile = open(s)
        for line in textfile:
            for word in line.split():
                if word in keyword.kwlist:
                    keydic[word] = keydic.get(word,0) + 1
        textfile.close()
    for i in slist:
        count_keys(i)
    return keydic
a = ['sun1.txt','sun-data.txt','test0.txt']
print(pykeys(a))
        
        
    
         
     

    
